let addons = [];
let currentAddonIndex = 0;
let selectedRating = 0;

// LOAD addons.json
fetch("addons.json")
  .then(res=>res.json())
  .then(data=>{addons=data; loadAddons();});

// LOAD ADDONS
function loadAddons(){
  let container=document.getElementById("addons");
  container.innerHTML="";
  addons.forEach((addon,index)=>{
    let card=document.createElement("div");
    card.className="card";
    card.innerHTML=`
      <h3>${addon.name}</h3>
      <img src="${addon.logo}"/>
      <p>${addon.description}</p>
      <img src="${addon.screenshot}"/>
      <button onclick="openModal(${index})">Download</button>
    `;
    container.appendChild(card);
  });
}

// MODAL
function openModal(i){
  currentAddonIndex=i;
  let addon=addons[i];
  document.getElementById("modalName").innerText=addon.name;
  document.getElementById("modalScreenshot").src=addon.screenshot;
  document.getElementById("modalDescription").innerText=addon.description;
  document.getElementById("modalFile").href=addon.file;
  document.getElementById("modalDownloads").innerText=addon.downloads||0;
  document.getElementById("addonModal").style.display="block";
  loadReviews();
}
function closeModal(){document.getElementById("addonModal").style.display="none";}

// DOWNLOAD
function downloadFromModal(){
  let addon=addons[currentAddonIndex];
  addon.downloads=(addon.downloads||0)+1;
  document.getElementById("modalDownloads").innerText=addon.downloads;
  document.getElementById("downloads-"+currentAddonIndex).innerText=addon.downloads;
  window.open(addon.file,"_blank");
}

// RATING & REVIEW
function selectRating(val){selectedRating=val;}
function submitReview(){
  let name=document.getElementById("reviewName").value.trim();
  let text=document.getElementById("reviewText").value.trim();
  if(!name)return alert("Enter name");
  if(selectedRating===0)return alert("Select rating");
  if(!text)return alert("Review message required");
  let key=addons[currentAddonIndex].folder+"_reviews";
  let reviews=JSON.parse(localStorage.getItem(key)||"[]");
  reviews.push({name:name,rating:selectedRating,text:text,replies:[]});
  localStorage.setItem(key,JSON.stringify(reviews));
  document.getElementById("reviewName").value="";
  document.getElementById("reviewText").value="";
  selectedRating=0;
  loadReviews();
}
function loadReviews(){
  let key=addons[currentAddonIndex].folder+"_reviews";
  let reviews=JSON.parse(localStorage.getItem(key)||"[]");
  let container=document.getElementById("reviewList");
  container.innerHTML="";
  let total=0;
  reviews.forEach((r,index)=>{
    total+=r.rating;
    let div=document.createElement("div");
    div.className="review";
    div.innerHTML=`
      <div class="review-name">${r.name}</div>
      <div class="review-stars">${"⭐".repeat(r.rating)}</div>
      <div>${r.text}</div>
      <button onclick="showReplyBox(${index})">Reply</button>
      <button onclick="deleteReview(${index})">Delete</button>
      <div id="replyBox${index}" style="display:none">
        <input id="replyName${index}" placeholder="Your name">
        <textarea id="replyText${index}" placeholder="Reply"></textarea>
        <button onclick="submitReply(${index})">Send</button>
      </div>
      <div id="replyList${index}"></div>
    `;
    container.appendChild(div);
    // LOAD REPLIES
    if(r.replies) r.replies.forEach(rep=>{
      let reply=document.createElement("div");
      reply.className="reply";
      reply.innerHTML=`<b>${rep.name}</b>: <div>${rep.text}</div>`;
      document.getElementById("replyList"+index).appendChild(reply);
    });
  });
  let avg=reviews.length?(total/reviews.length).toFixed(1):0;
  document.getElementById("avgRating").innerText=avg;
  document.getElementById("ratingCount").innerText=reviews.length;
}
function showReplyBox(index){
  let box=document.getElementById("replyBox"+index);
  box.style.display=(box.style.display==="none"||box.style.display==="")?"block":"none";
}
function submitReply(index){
  let name=document.getElementById("replyName"+index).value.trim();
  let text=document.getElementById("replyText"+index).value.trim();
  if(!name)return alert("Enter name");
  if(!text)return alert("Reply message required");
  let key=addons[currentAddonIndex].folder+"_reviews";
  let reviews=JSON.parse(localStorage.getItem(key)||"[]");
  reviews[index].replies.push({name:name,text:text});
  localStorage.setItem(key,JSON.stringify(reviews));
  loadReviews();
}
function deleteReview(index){
  let key=addons[currentAddonIndex].folder+"_reviews";
  let reviews=JSON.parse(localStorage.getItem(key)||"[]");
  reviews.splice(index,1);
  localStorage.setItem(key,JSON.stringify(reviews));
  loadReviews();
}